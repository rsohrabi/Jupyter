""" This is a basic module to show how
to use the setup and dist package tools.
"""